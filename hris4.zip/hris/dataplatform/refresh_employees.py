import requests
import json
import pandas as pd
import pandas.io.sql as psql
from pathlib import Path
import mysql.connector as mysql
import pandas as pd
from sqlalchemy import create_engine

#Token is at the settings pane of the Kobo toolbox; near the logout menu
TOKEN = '59a59622c27a85f3b96e15d1787fbbe36bad69b7'

#We need the headers as a means to login to Kobo toolbox server from third party tools
headers = {"Authorization": f'Token {TOKEN}'}

KF_URL = 'kc.kobotoolbox.org/api/v1/'
#Users with the non-humanitaria Kobo toolbox server should use the end point https://kc.kobotoolbox.org/api/v1/
#Users with the humanitaria Kobo toolbox server should use the end point kobo.humanitarianresponse.info

#Asset Id retrived from kobo toolbox; click on a form then retrieve the value between forms and summary
FARMER_ASSET_UID = 'aZFfTMcMZDYf6RUFiwBuxf'
#FARM_ASSET_UID = 'FORM2_TOOLBOX_ID'

#JSON based URLs for the two forms
FARMER_URL = f'https://{KF_URL}/api/v2/assets/{FARMER_ASSET_UID}/data/?format=json'
#FARM_URL = f'https://{KF_URL}/api/v2/assets/{FARM_ASSET_UID}/data/?format=json'

# MySQL database connection
import mysql.connector as mysql
import pandas as pd

mysql_port=3306
port_tuple = (3306,)
# Establishing a MySQL database connection
# Database connection parameters
user="root",
password="Maun2806;",
host="localhost",
port = 3306,
database="nursing_hris"

# print(port)
# print(port_tuple[0])

# Create a SQLAlchemy engine
connection_string = f"mysql+mysqlconnector://{user}:{password}@{host}:{port}/{database}"
engine = create_engine(connection_string)

# Define the SQL query
query = """
SELECT e.nursing_reg_no AS nursing_reg_no, e.id AS database_id, 
       CONCAT_WS(' ', e.nursing_reg_no, e.firstname, e.middle_name, e.lastname) AS employee_details,
       e.employment_no, e.dob, e.gender, e.email, e.phone,
       e.hire_date, sc.countyName AS county, e.sub_county_id, 
       LOWER(sc.subCounty) AS sub_county, e.facility_id, 
       hf.name AS health_facility
FROM nursing_hris.employee e  
JOIN sub_county sc ON sc.id = e.sub_county_id
JOIN health_facilities hf ON hf.id = e.facility_id
WHERE e.is_active = 1;
"""

# Read the SQL query into a DataFrame
try:
    farmers_list = pd.read_sql(query, engine)
    # Export to CSV
    farmers_list.to_csv("employee_list.csv", index=False)
except Exception as e:
    print(f"An error occurred: {e}")
finally:
    # Dispose of the engine
    engine.dispose()


#now change the new CSV for the farm survey

XFORM = 2294849
#xform is theunique id kobo assigned the form we wish to update the CSV media file for
KC_URL = 'https://kc.kobotoolbox.org/api/v1/'
#KC_URL = 'https://kc.humanitarianresponse.info/api/v1/'  #for the humanitarian or EU users
#We need the KC URL to update media files

#While in an active login session for Kobo toolbox
#use the URLs below to get the XForm value that corresponds with a form of interest
#https://kc.kobotoolbox.org/api/v1/metadata.json
#https://kc.humanitarianresponse.info/api/v1/forms.json


#Details specific to CSV media file
FILE_FOLDER = '.'  #.means we will be processing the media file from the current directory
FILENAME = 'employee_list.csv'
MIME = 'text/csv'

#The portion below handles the gist of the CSV media replacement
headers = {'Authorization': f'Token {TOKEN}'}
files = {'data_file': (FILENAME, open(fr'{FILE_FOLDER}\{FILENAME}', 'rb').read(), MIME)}
data = {
        'data_value': FILENAME,
        'xform': XFORM,
        'data_type': 'media',
        'data_file_type': MIME,
    }

    # Download metadata.json
response = requests.get(fr"{KC_URL}/metadata.json", headers=headers)
dict_response = json.loads(response.text)

    # Delete appropriate entry in the metadata.json (delete old file)
for each in dict_response:
        if each['xform'] == XFORM and each['data_value'] == FILENAME:
            del_id = each['id']
            response = requests.delete(fr"{KC_URL}/metadata/{del_id}", headers=headers)
            break

# Upload the changed file
response = requests.post(fr"{KC_URL}/metadata.json", data=data, files=files, headers=headers)

print(response)