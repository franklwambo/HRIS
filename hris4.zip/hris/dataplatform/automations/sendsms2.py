import http.client

conn = http.client.HTTPSConnection("sms.movesms.co.ke")
payload = ''
headers = {}
conn.request("POST", "/api/compose?api_key=XlAcaJSETi1GJPX78cjHmylwtNV68KH9H7v0oKC5xfviiMYs53&sender=SMARTLINK&username=franklwambo&to=254729564904&message=Pleaserenew%20your%nursingpracticelicense%20l&msgtype=5&dlr=0", payload, headers)
res = conn.getresponse()
data = res.read()
print(data.decode("utf-8"))