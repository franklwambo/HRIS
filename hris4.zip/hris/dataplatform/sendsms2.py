import requests
import urllib3
#from django.conf import settings  # Import Django settings

# Disable InsecureRequestWarning about SSL verification
urllib3.disable_warnings(urllib3.exceptions.InsecureRequestWarning)

def send_message(receiver, message_context):
    # Access SMS API credentials from Django settings
    username = 'franklwambo'
    api_key = 'XlAcaJSETi1GJPX78cjHmylwtNV68KH9H7v0oKC5xfviiMYs53'
    sender_id = 'SMARTLINK'
    
    # Create the message payload
    post_data = {
        'username': username,
        'api_key': api_key,
        'sender': sender_id,
        'to': receiver,
        'message': message_context,
        'msgtype': 5,  # Message type
        'dlr': 0,      # Delivery report (0 = no report)
    }
    
    url = "https://sms.movesms.co.ke/api/compose?"
    
    # Add headers to mimic a valid request (adjust according to the API's requirement)
    headers = {
        'Content-Type': 'application/x-www-form-urlencoded',  # Typically for form submissions
        
    }
    
    try:
        # Print the request details for debugging
        print(f"Sending POST request to: {url}")
        print(f"Payload: {post_data}")
        
        # Send the POST request without SSL verification (warning will be suppressed)
        response = requests.post(url, data=post_data, headers=headers, verify=False)
        
        # Print the response (for debugging)
        print(f"Response Code: {response.status_code}")
        print(f"Response Text: {response.text}")
        
        # Check for HTTP request errors
        response.raise_for_status()  # Raises HTTPError for bad responses
        
    except requests.exceptions.RequestException as e:
        # Handle any request-related errors (e.g., connection issues)
        print(f"An error occurred: {e}")
        

# Example usage
receiver = "+254729564904"  # Replace with the actual receiver's phone number
message = "I am testing this alert for the nursing counsil system"  # The message to send

send_message(receiver, message)
