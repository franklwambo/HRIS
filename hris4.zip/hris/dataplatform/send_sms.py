import africastalking

# Initialize the SDK
# username = "sandbox"  # Replace with your Africa's Talking username
# api_key = "atsk_7e136d71e09fe10cc7cbafb25a179397657855a3a5e83d8ee5468a26061a3e4842b7b07b"     # Replace with your Africa's Talking API key
# api_key = "atsk_7e136d71e09fe10cc7cbafb25a179397657855a3a5e83d8ee5468a26061a3e4842b7b07b" 

username = "hrisalert"  # Replace with your Africa's Talking username
api_key = "atsk_04f7e95062e839f9ef5b1945f00691a8cf996f2ace3727866d14b4321d2e34735159005b" 
county = "Mombasa"
#api_key = "atsk_91e51b31b05d5da522a77bcaa922c6f2e74e541de9ce5536a288de47c3588905f8b11b4a" 

africastalking.initialize(username, api_key)

# Get the SMS service
sms = africastalking.SMS

def send_sms(to, message):
    try:
        response = sms.send(message, [to])
        print("SMS sent successfully.")
        print(response)
    except Exception as e:
        print("Error while sending SMS:", e)

# Example usage
#recipient_number = "+254729564904"  
#recipient_number = "+254790695327"
recipient_number = "+254734883542"  
reminder_message = "This is a kind reminder that it is past 15th and you have not entered the maternal and neonatal mortality log for " + county + " county"

send_sms(recipient_number, reminder_message)
