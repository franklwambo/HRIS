from rest_framework import serializers
from .models import County, SubCounty, Employee

class CountySerializer(serializers.ModelSerializer):
    class Meta:
        model = County
        fields = ['id', 'countyName']

class SubCountySerializer(serializers.ModelSerializer):
    county = CountySerializer()  # Nested serializer to include County details

    class Meta:
        model = SubCounty
        fields = ['id', 'county', 'countyName', 'subCounty']

class EmployeeSerializer(serializers.ModelSerializer):
    sub_county = SubCountySerializer()  # Nested serializer to include SubCounty details

    class Meta:
        model = Employee
        fields = [
            'id', 'employment_no', 'nursing_reg_no','firstname', 'middle_name', 'lastname','dob',
            'gender', 'email', 'phone', 'hire_date', 'sub_county', 'is_active'
        ]
