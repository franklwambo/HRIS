from django.apps import AppConfig


class DataplatformConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'dataplatform'
