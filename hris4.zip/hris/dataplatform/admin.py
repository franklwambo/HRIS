from django.contrib import admin
from . models import *

# Register your models here.

admin.site.register(UserCountyRelation)
admin.site.register(PermissionLevel)
admin.site.register(County)
admin.site.register(SubCounty)
admin.site.register(MortalityType)
admin.site.register(MortalityLog)
admin.site.register(Employee)
admin.site.register(EmploymentType)
admin.site.register(StaffEmploymentTypeRelation)
admin.site.register(StaffLicenseLog)
