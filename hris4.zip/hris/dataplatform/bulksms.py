import http.client
import urllib.parse
import ssl
import json

# Define the variables
user = "franklwambo"
userpass = "55556666#!2024"
senderId = "SMARTLINK"
mobile = "254729564904"
msg = "This is my first message with MoveSMS"
api_key="XlAcaJSETi1GJPX78cjHmylwtNV68KH9H7v0oKC5xfviiMYs53"

# Prepare the payload
payload = urllib.parse.urlencode({
    'userId': user,
    'password': userpass,
    'senderId': senderId,
    'sendMethod': 'simpleMsg',
    'msgType': 'text',
    'mobile': mobile,
    'msg': msg,
    'duplicateCheck': 'true',
    'format': 'json'
    #'scheduleTime': '2017-06-13 20:22:00'  # You can modify this as per your needs
})

# Set headers
headers = {
    'apikey': api_key,
    'content-type': "application/x-www-form-urlencoded",
    'cache-control': "no-cache"
}

# Create an SSL context that does not verify certificates
context = ssl._create_unverified_context()

# Create an HTTPS connection and send the request using the context
conn = http.client.HTTPSConnection("sms.movesms.co.ke", context=context)
conn.request("POST", "/api", payload, headers)

# Get the response and print the result
res = conn.getresponse()
data = res.read()

print(data)

#print(data.decode("utf-8"))
