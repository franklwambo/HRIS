import requests
import json
import pandas as pd
import mysql.connector
from pathlib import Path

# Token for Kobo Toolbox
TOKEN = '59a59622c27a85f3b96e15d1787fbbe36bad69b7'
headers = {"Authorization": f'Token {TOKEN}'}

#for x-form IDs navigate to the following in an active session
#https://kc.kobotoolbox.org/api/v1/forms
# Use the appropriate Kobo Toolbox URL
KF_URL = 'kc.kobotoolbox.org'  # Update to your non-humanitarian endpoint if needed
XFORM = '2294849'  # Unique ID for the target form
KC_URL = 'https://kc.kobotoolbox.org/api/v1/'

# MySQL database connection
connection = mysql.connector.connect(
    user="root",
    password="Maun2806;",
    host="localhost",
    port="3306",
    database="nursing_hris"
)

cursor = connection.cursor()

# Fetch employee details from MySQL
employee_query = """
    SELECT e.nursing_reg_no as nursing_reg_no, e.id as database_id, 
           CONCAT_WS(' ', e.nursing_reg_no, e.firstname, e.middle_name, e.lastname) as employee_details,
           e.employment_no, e.dob, e.gender, e.email, e.phone,
           e.hire_date, sc.countyName as county, e.sub_county_id, LOWER(sc.subCounty) as sub_county,
           e.facility_id, hf.name as health_facility
    FROM nursing_hris.employee e  
    JOIN sub_county sc ON sc.id = e.sub_county_id
    JOIN health_facilities hf ON hf.id = e.facility_id
    WHERE e.is_active = 1;
"""

cursor.execute(employee_query)
employees = cursor.fetchall()

# Create a DataFrame from employee data
columns = [
    "nursing_reg_no", "database_id", "employee_details", "employment_no", 
    "dob", "gender", "email", "phone", "hire_date", "county", 
    "sub_county_id", "sub_county", "facility_id", "health_facility"
]
employees_df = pd.DataFrame(employees, columns=columns)

# Save employee data to CSV
FILENAME = 'employee_list.csv'
employees_df.to_csv(FILENAME, index=False)

# Details specific to CSV media file
FILE_FOLDER = '.'  # Current directory
MIME = 'text/csv'

# Handling the CSV media replacement
files = {'data_file': (FILENAME, open(f'{FILE_FOLDER}/{FILENAME}', 'rb'), MIME)}
data = {
    'data_value': FILENAME,
    'xform': XFORM,
    'data_type': 'media',
    'data_file_type': MIME,
}

# Download metadata.json
response = requests.get(f"{KC_URL}/metadata.json", headers=headers)
dict_response = response.json()

# Delete old file entry in the metadata.json (if exists)
for each in dict_response:
    if each['xform'] == XFORM and each['data_value'] == FILENAME:
        del_id = each['id']
        requests.delete(f"{KC_URL}/metadata/{del_id}", headers=headers)
        break

# Upload the changed file
response = requests.post(f"{KC_URL}/metadata.json", data=data, files=files, headers=headers)

print(response)
