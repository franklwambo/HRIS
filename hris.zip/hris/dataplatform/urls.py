from django.urls import path
from django.contrib import admin
from . import views
from django.views.generic import TemplateView    
from django.contrib.auth.views import LogoutView
from .views import CustomLoginView

urlpatterns = [

    #path('employees/', views.dp_employee_list, name='dp_employee_list'),
    path('', views.dp_employee_list, name='dp_employee_list'),
    path('employee/subcounties', views.get_subcounties_in_county, name='get_subcounties_in_county'),
    path('employee/subcountyfacilities', views.get_facilities_in_subcounty, name='get_facilities_in_subcounty'),
    path('employee/create/', views.create_employee_record, name='create_employee_record'),
    path('employee/update/<int:id>/', views.update_employee_record, name='update_employee_record'),
    path('employee/delete/', views.delete_employee_record, name='delete_employee_record'),
    path('api/employee/<int:id>/', views.EmployeeDetailsAPI, name="EmployeeDetailsAPI"),
    path('employee/<int:employee_id>/', views.employee_detail, name='employee_detail'),

    path('employee/enrollment/template/', views.enrollment_template_download, name='enrollment_template'),
    path('employee/enrollment/upload/', views.upload_nursemid_staff, name='upload_staff'),

    path('employee/license/create/', views.license_renewal_create, name='license_create'),
    path('employee/qualification/create/', views.qualification_create, name='qualification_create'),
    path('employee/placement/create/', views.departmental_placement_create, name='departmental_placement'),
    path('employee/exit/create/', views.staff_exit, name='staff_exit'),

    path('employee/employee-data/', views.employee_data, name='employee_data'),
    path('chart/', views.chart, name='chart'),

    path('employee/employee_qualification/', views.employee_qualification_json, name='employee_qualification_json'),
    path('employee/employee_engagement/', views.employee_engagement_json, name='employee_engagement_json'),
    path('employee/employee_age/', views.employee_age_json, name='employee_age_json'),
    path('employee/employee_hiretrends/', views.employee_hiretrends_json, name='employee_hiretrends_json'),
    path('hrischart/', views.qualificationchart, name='qualificationchart'),

    path('dashboard-staff/', views.staff_dashboard, name='staff_dashboard'),


    # path('mortality/<int:county>/', views.mortality_detail, name='mortality_detail'),
    path('mortality/', views.mortality_detail, name='mortality_detail'),
    path('county/mortality/create/', views.log_maternal_mortality, name='log_mortality'),
    path('county/neomortality/create/', views.log_neonatal_mortality, name='log_neo_mortality'),

    # path('logout/', LogoutView.as_view(next_page='/login/'), name='logout'),
    path('login/', CustomLoginView.as_view(), name='login'),

    path('map-county/', views.location_mapper, name='location_mapper'), 

    path('welcome/', views.home_page, name='home_page'), 

    

]    