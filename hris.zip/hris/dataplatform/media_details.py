import requests

# Replace with your Kobo API URL and token
KC_URL = "https://kc.kobotoolbox.org/api/v2/assets"
TOKEN = "59a59622c27a85f3b96e15d1787fbbe36bad69b7"  # Replace with your API token

headers = {
    "Authorization": f"Bearer {TOKEN}",
    "Content-Type": "application/json"
}

response = requests.get(KC_URL, headers=headers)

if response.status_code == 200:
    media_data = response.json()
    print(media_data)  # This will print the JSON containing media file details
else:
    print(f"Failed to retrieve media files: {response.status_code} - {response.text}")
