import smtplib
from email.mime.multipart import MIMEMultipart
from email.mime.text import MIMEText
from email.utils import formataddr

# Email details
smtp_server = 'smtp.office365.com'
smtp_port = 587
from_email = 'fopiyo@jhpiego.org'
display_name = 'Your Name'
to_email = 'fopiyo@jhpiego.org'
subject = 'Alert on BOA Expiry'
body = 'This is the email body.'
username = 'fopiyo@jhpiego.org'  # Same as from_email
password = 'Jhp-KE00859'  # Your email password

# Create the email message
msg = MIMEMultipart()
msg['From'] = formataddr((display_name, from_email))
msg['To'] = to_email
msg['Subject'] = subject
msg.attach(MIMEText(body, 'plain'))

try:
    # Connect to the server
    with smtplib.SMTP(smtp_server, smtp_port) as server:
        server.starttls()  # Upgrade to a secure connection
        server.login(username, password)
        server.sendmail(from_email, to_email, msg.as_string())
        print('Email sent successfully!')
except Exception as e:
    print(f'Failed to send email: {e}')
