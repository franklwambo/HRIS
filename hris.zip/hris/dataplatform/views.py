from django.shortcuts import render, redirect
from django.contrib.auth.decorators import login_required
from django.urls import include
from .models import *
from .serializers import *
from django.http import JsonResponse
from datetime import datetime
from django.db import connection

from rest_framework.decorators import api_view
from rest_framework.response import Response
from rest_framework import status
from django.shortcuts import get_object_or_404
from django.http import HttpResponse  #also needed for Execl template download
import openpyxl #specific to Excel template download
from django.core.exceptions import ValidationError #this validates the imported Excel file
from django.contrib import messages
from django.contrib.auth.decorators import login_required
from django.db.models.functions import Lower

from django.contrib.auth.models import AbstractUser, User
from django.db import transaction

from django.utils.dateparse import parse_date

from .analytics_extras import *
from django.contrib.auth.views import LoginView

from django.db.models import Count
from django.db.models.functions import TruncYear
from django.db.models.functions import ExtractYear

# from django.db.models.functions import age

def location_mapper(request):
    user_county_relation = UserCountyRelation.objects.filter(hris_user=request.user).first()
    return render(request, 'base.html', {'user_county_relation': user_county_relation})

def home_page(request):
    return render(request, 'welcome.html')

class CustomLoginView(LoginView):
    def form_valid(self, form):
        # Call the parent form_valid method to log in the user
        response = super().form_valid(form)

        # Grab the user ID
        user_id = form.get_user().id
        self.request.session['user_id'] = user_id

        if form.is_valid():
            user = form.get_user()
            if user:
                user_id = user.id
                self.request.session['user_id'] = user_id
            else:
                print("No user found")
        else:
            print("Form is invalid" +user)


        # Query the UserCountyRelation for the county
        #user_county_relation = UserCountyRelation.objects.filter(hris_user=user_id, is_active=True).first()


        # user_county_relation = UserCountyRelation.objects.filter(hris_user=user_id).first()

        # if user_county_relation:
        #     county = user_county_relation.county
        #     self.request.session['county_id'] = county.id

        return response

# Create your views here.

def calculate_age(birth_date):
    today = date.today()
    return today.year - birth_date.year - ((today.month, today.day) < (birth_date.month, birth_date.day))


@login_required
def dp_employee_list(request):
    counties = County.objects.all().order_by(Lower('countyName')).values('id','countyName')
    subcounties = SubCounty.objects.all().values('id','subCounty')
    staff_qualififications = QualificationType.objects.all().values('id','description')
    employment_types = EmploymentType.objects.all().values('id','description')
    healthfacilities = Healthfacility.objects.all().values('id','name')
    staff_list=NurseMidStaffEnrollmentSummary.objects.values('id','nursing_reg_no','employment_no','firstname','middle_name','lastname',
                                                          'gender','email','phone', 'hire_date','county','sub_county',
                                                          'age')
    # employees = Employee.objects.annotate(
    # age=age('dob')
    # ).values('id', 'employment_no', 'nursing_reg_no','firstname', 'middle_name', 'lastname','dob',
    #         'gender', 'email', 'phone', 'hire_date', 'sub_county', 'sub_county__countyName','is_active','createdby__username','datecreated','sub_county__county__countyName','sub_county__subCounty')
    
    employees = Employee.objects.all().values('id', 'employment_no', 'nursing_reg_no','firstname', 'middle_name', 'lastname','dob',
            'gender', 'email', 'phone', 'hire_date', 'sub_county', 'sub_county__countyName','is_active','createdby__username','datecreated','sub_county__county__countyName','sub_county__subCounty')
    
    for employee in employees:
    # Ensure that the 'dob' field is not null
        if employee['dob']:
            employee['age'] = calculate_age(employee['dob'])
    # user_id = request.session.get('user_id')  
    user_id = request.user 
    assigned_counties = []  # Initialize assigned_counties list

    if user_id:
        try:
            
            assigned_counties = UserCountyRelation.objects.filter(hris_user=request.user, is_active=True)
        except UserCountyRelation.DoesNotExist:
            assigned_counties = []

    if assigned_counties:
        for relation in assigned_counties:
           county_name = relation.county
           selected_county = relation.county.id
        employees = employees.filter(sub_county__countyName=county_name)
        counties = counties.filter(id=selected_county)
        subcounties = subcounties.filter(county=selected_county)

    else:
        employees = employees
        counties = counties    
        subcounties = subcounties    
    # employees = employees.filter(geoID=geography_filters)
    context = {
        'p_name': 'Nurses and Midewifery: Staff List',
        'counties': counties,
        'subcounties':subcounties,
        'employees':employees,
        'staff_qualififications':staff_qualififications,
        'employment_types':employment_types,
        'assigned_counties':assigned_counties,
        'healthfacilities':healthfacilities,
        'selected_county':selected_county,
        'county_name':county_name,
        'staff_list':staff_list,
                
    }
    #return render(request, 'employee.html', context)
    return render(request, 'staff.html', context)

@login_required
@api_view(['GET'])
def EmployeeDetailsAPI(request, id):
    employee = get_object_or_404(Employee, id=id)
    serializer = EmployeeSerializer(employee, many=False)
    return Response(serializer.data, status=status.HTTP_200_OK)

def mortality_detail(request):
    selected_county = request.GET.get('county_code', None)
    county = get_object_or_404(County, id=selected_county)
    county_detail = f" {county.countyName} - county code - {county.id}"
            
    counties = County.objects.all().values('id','countyName')
    mortality_types = MortalityType.objects.all().values('id','description')

    maternal_mortality_code = 1
    neonatal_mortality_code = 2

    mortality_logs = MortalityLog.objects.all().values('id','county', 'county__countyName','mortality_type', 'mortality_count',
                                                                                       'mortality_type__description','date_reported','datecreated','createdby__username')
    if selected_county:
        mortality_logs = mortality_logs.filter(county=county)
    else:
         mortality_logs=mortality_logs       
    
    # maternal_mortalities = MortalityLog.objects.all().values('id','county', 'county__countyName','mortality_type', 'mortality_count',
    #                                                                                    'mortality_type__description','date_reported','datecreated','createdby__username')

    neonatal_mortalities = mortality_logs.filter(mortality_type=neonatal_mortality_code)
    maternal_mortalities = mortality_logs.filter(mortality_type=maternal_mortality_code)
    

    context = {
                  'county': county,
                  'county_detail': county_detail,
                  'counties':counties,
                  'mortality_types':mortality_types,
                  'neonatal_mortalities':neonatal_mortalities,
                  'maternal_mortalities':maternal_mortalities,
                  
                  }
    
    return render(request, 'mortality.html', context)

#The Excel file for employee download goes here
def enrollment_template_download2(request):
    # Create a new workbook and worksheet
    wb = openpyxl.Workbook()
    ws = wb.active
    ws.title = "Employee Template"
    
    # Create headers for the template (adjust as needed)
    headers = ['Employee ID', 'First Name', 'Last Name', 'Email', 'Date of Birth', 'Hire Date', 'Department']
    ws.append(headers)
    
    # Optionally, add some default data (e.g., a sample row)
    ws.append([1, 'John', 'Doe', 'john.doe@example.com', '1990-01-01', '2020-01-01', 'HR'])
    ws.append([2, 'Jane', 'Smith', 'jane.smith@example.com', '1985-05-15', '2019-02-20', 'Finance'])

    # Create an HTTP response with the correct content type for an Excel file
    response = HttpResponse(content_type='application/vnd.openxmlformats-officedocument.spreadsheetml.sheet')
    response['Content-Disposition'] = 'attachment; filename=employee_template.xlsx'

    # Save the workbook to the response
    wb.save(response)
    return response


def generate_excel_template(file_name, headers, sample_data, data_entry_headers):
    """
    Generates an Excel file with two sheets:
    1. Template sheet with headers and sample data.
    2. Data entry sheet with only the column headers.
    """
    # Create a new workbook
    wb = openpyxl.Workbook()

    # Create the Template sheet (This is your original sheet with the headers and sample data)
    template_ws = wb.active
    template_ws.title = "Template"
    template_ws.append(headers)
    
    # Add sample data to the template sheet
    for row in sample_data:
        template_ws.append(row)
    
    # Create the Data Entry sheet with just the column headers
    data_entry_ws = wb.create_sheet(title="Stafflist")
    data_entry_ws.append(data_entry_headers)

    # Create an HTTP response with the correct content type for an Excel file
    response = HttpResponse(content_type='application/vnd.openxmlformats-officedocument.spreadsheetml.sheet')
    response['Content-Disposition'] = f'attachment; filename={file_name}'
    
    # Save the workbook to the response
    wb.save(response)
    return response

def enrollment_template_download(request):
    # Define file name, headers, and sample data for the template
    file_name = "NurseMid_EnrollmentData.xlsx"
    headers = ['Employee ID', 'First Name', 'Last Name', 'Email', 'Date of Birth', 'Hire Date', 'Department']
    sample_data = [
        [1, 'John', 'Doe', 'john.doe@example.com', '1990-01-01', '2020-01-01', 'HR'],
        [2, 'Jane', 'Smith', 'jane.smith@example.com', '1985-05-15', '2019-02-20', 'Finance']
    ]
    
    # Define data entry headers (the columns for the data entry sheet)
    data_entry_headers = ['Employee ID', 'First Name', 'Last Name', 'Email', 'Date of Birth', 'Hire Date', 'Department']
    
    # Call the generate_excel_template function with the parameters
    return generate_excel_template(file_name, headers, sample_data, data_entry_headers)


def process_excel(file):
    """
    Process the uploaded Excel file and return the data from the 'Data Entry' sheet.
    """
    wb = openpyxl.load_workbook(file)
    
    # Check if the 'Data Entry' sheet exists
    if "Data Entry" not in wb.sheetnames:
        raise ValidationError("The Excel file must contain a 'Data Entry' sheet.")
    
    # Get the 'Data Entry' sheet
    data_entry_sheet = wb["Data Entry"]
    
    # Get all rows of data (skip the first row, which contains the headers)
    rows = list(data_entry_sheet.iter_rows(min_row=2, values_only=True))
    
    return rows

def upload_nursemid_staff(request):
    """
    View to handle Excel file upload via AJAX and save data to Employee model.
    """
    if request.method == "POST" and request.FILES.get('excel_file'):
        excel_file = request.FILES['excel_file']
        
        try:
            # Process the Excel file
            employee_data = process_excel(excel_file)
            
            # Save data to the database
            for row in employee_data:
                employee_id, first_name, last_name, email, date_of_birth, hire_date, department = row
                
                # Create and save the employee instance
                Employee.objects.create(
                    employee_id=employee_id,
                    first_name=first_name,
                    last_name=last_name,
                    email=email,
                    date_of_birth=date_of_birth,
                    hire_date=hire_date,
                    department=department
                )
            
            # Return a success response
            return JsonResponse({'status': 'success', 'message': 'Data uploaded successfully!'})
        
        except ValidationError as e:
            # Return error if validation fails (e.g., missing "Data Entry" sheet)
            return JsonResponse({'status': 'error', 'message': str(e)})
        except Exception as e:
            # Handle other errors (e.g., malformed file, missing columns)
            return JsonResponse({'status': 'error', 'message': str(e)})

    return JsonResponse({'status': 'error', 'message': 'Invalid request.'})

def employee_detail(request, employee_id):
    employee = get_object_or_404(Employee, id=employee_id)
    employee_details = f"{employee.nursing_reg_no} - {employee.employment_no} - {employee.firstname} {employee.middle_name} {employee.lastname} {employee.id}"
    employee_detail = f" {employee.firstname} {employee.lastname} - identified by registration - {employee.nursing_reg_no}"
    qualifications = EmployeeQualification.objects.filter(employee=employee_id).values('id','employee', 'employee__nursing_reg_no','qualification', 
                                                                                       'qualification__description','date_entered','datecreated','createdby__username')
    qualification_types = QualificationType.objects.all().values('id','description')
    licenserenewal = StaffLicenseLog.objects.filter(is_active=1).values('id', 'employee', 'date_renewed', 'expiry_date', 'employee__nursing_reg_no').order_by('-datecreated')[:1]

    facility_departments = FacilityDepartment.objects.all().values('id','description', 'verbose_name').order_by('description')
    placements = StaffDepartmentRelation.objects.filter(employee=employee_id).values('id','employee', 'employee__nursing_reg_no','department', 
                                                                                     'department__description','date_placed','is_active','datecreated','createdby__username')
    
    exit_types = ExitType.objects.all().values('id','description')
    employee_exits = EmployeeExit.objects.filter(employee=employee_id).values('id','employee', 'exit_type', 'exit_type__description',
                                                                                     'date_entered','is_active','datecreated','createdby__username').order_by('date_entered')

    context = {
                  'employee': employee,
                  'employee_details': employee_details,
                  'employee_detail': employee_detail,
                  'qualifications': qualifications,
                  'qualification_types': qualification_types,
                  'facility_departments': facility_departments,
                  'placements': placements,
                  'exit_types': exit_types,
                  'employee_exits': employee_exits,
                  'licenserenewal': licenserenewal,
                  }
    
    return render(request, 'employee_detail.html', context)

def qualification_create(request):
    if request.method == 'POST':
        # Get dhis2ID from POST data
        qualification_id = request.POST.get('qualification_id')
        if qualification_id is None or qualification_id == '':
            qualification_id = 0
        else:
            qualification_id = int(qualification_id)

        employee = request.POST.get('employee_id')
        # employee = get_object_or_404(Employee, id=employee)

        # Try to get the existing action item, or create a new one if not found
        try:
            qualification_status = EmployeeQualification.objects.get(id=qualification_id)
            qualification_status.updatedby = request.user
            qualification_status.qualification_specialization=request.POST.get('specialization')
            qualification_status.year_obtained = request.POST.get('year_obtained')
            selected_qualification = request.POST.get('qualification')
            qualification_status.qualification = QualificationType.objects.get(id=selected_qualification)
            qualification_status.employee = Employee.objects.get(id=employee)
            datereported_str = request.POST.get('date_entered')
            
       
            if datereported_str:
                datereported = parse_date(datereported_str)
            else:
                datereported = None
            qualification_status.date_entered=datereported 

        except EmployeeQualification.DoesNotExist:
            qualification_status = EmployeeQualification()
            qualification_status.createdby = request.user
            qualification_status.qualification_specialization=request.POST.get('specialization')
            qualification_status.year_obtained = request.POST.get('year_obtained')
            selected_qualification = request.POST.get('qualification')
            qualification_status.qualification = QualificationType.objects.get(id=selected_qualification)
            qualification_status.employee = Employee.objects.get(id=employee)
            datereported_str = request.POST.get('date_entered')
            # print('This is the date '+datereported_str)
       
            if datereported_str:
                datereported = parse_date(datereported_str)
            else:
                datereported = None
        qualification_status.date_entered=datereported
           
        
        qualification_status.save()

        messages.success(request,
                         f'Details successfully updated.')
        # return redirect('employee_detail', employee_id=employee.id)
        return redirect('employee_detail', employee_id=employee)
    #     return redirect('dp_employee_list')

    # return redirect('dp_employee_list')


def license_renewal_create(request):
    if request.method == 'POST':
        # Get dhis2ID from POST data
        renewal_id = request.POST.get('license_renewal_id')
        if renewal_id is None or renewal_id == '':
            renewal_id = 0
        else:
            renewal_id = int(renewal_id)

        employee = request.POST.get('employee_id')
        # employee = get_object_or_404(Employee, id=employee)

        # Try to get the existing action item, or create a new one if not found
        try:
            renewal_status = StaffLicenseLog.objects.get(id=renewal_id)
            renewal_status.updatedby = request.user
            renewal_status.employee = Employee.objects.get(id=employee)

            renewaldate_str = request.POST.get('date_renewed')
            if renewaldate_str:
                daterenewed = parse_date(renewaldate_str)
            else:
                daterenewed = None
            renewal_status.date_renewed=daterenewed 

            expirydate_str = request.POST.get('expiry_date')
            if expirydate_str:
                expirydate = parse_date(expirydate_str)
            else:
                expirydate = None
            renewal_status.expiry_date=expirydate 

        except StaffLicenseLog.DoesNotExist:
            renewal_status = StaffLicenseLog()
            renewal_status.createdby = request.user
            renewal_status.employee = Employee.objects.get(id=employee)
            

            renewaldate_str = request.POST.get('date_renewed')
            if renewaldate_str:
                daterenewed = parse_date(renewaldate_str)
            else:
                daterenewed = None
            renewal_status.date_renewed=daterenewed 

            expirydate_str = request.POST.get('expiry_date')
            if expirydate_str:
                expirydate = parse_date(expirydate_str)
            else:
                expirydate = None
            renewal_status.expiry_date=expirydate 
           
        
        renewal_status.save()

        messages.success(request,
                         f'Details successfully updated.')
        # return redirect('employee_detail', employee_id=employee.id)
        return redirect('employee_detail', employee_id=employee)    


def departmental_placement_create(request):
    if request.method == 'POST':
        # Get dhis2ID from POST data
        placement_id = request.POST.get('placement_id')
        if placement_id is None or placement_id == '':
            placement_id = 0
        else:
            placement_id = int(placement_id)

        employee = request.POST.get('employee_id')
        # employee = get_object_or_404(Employee, id=employee)

        # Try to get the existing action item, or create a new one if not found
        try:
            placement_status = StaffDepartmentRelation.objects.get(id=placement_id)
            placement_status.updatedby = request.user
            selected_department = request.POST.get('placement_department')
            placement_status.department_other=request.POST.get('department_other')
            placement_status.department = FacilityDepartment.objects.get(id=selected_department)
            placement_status.employee = Employee.objects.get(id=employee)
            datereported_str = request.POST.get('date_placed')
            
       
            if datereported_str:
                datereported = parse_date(datereported_str)
            else:
                datereported = None
            placement_status.date_placed=datereported 

        except StaffDepartmentRelation.DoesNotExist:
            placement_status = StaffDepartmentRelation()
            placement_status.createdby = request.user
            selected_department = request.POST.get('placement_department')
            placement_status.department_other=request.POST.get('department_other')
            placement_status.department = FacilityDepartment.objects.get(id=selected_department)
            placement_status.employee = Employee.objects.get(id=employee)
            datereported_str = request.POST.get('date_placed')
            
       
            if datereported_str:
                datereported = parse_date(datereported_str)
            else:
                datereported = None
        placement_status.date_placed=datereported
           
        
        placement_status.save()

        messages.success(request,
                         f'Details successfully updated.')
        # return redirect('employee_detail', employee_id=employee.id)
        return redirect('employee_detail', employee_id=employee)
    #     return redirect('dp_employee_list')    

def staff_exit(request):
    if request.method == 'POST':
        # Get dhis2ID from POST data
        exit_id = request.POST.get('exit_id')
        if exit_id is None or exit_id == '':
            exit_id = 0
        else:
            exit_id = int(exit_id)

        employee = request.POST.get('employee_id')
        # employee = get_object_or_404(Employee, id=employee)

        # Try to get the existing action item, or create a new one if not found
        try:
            exit_status = EmployeeExit.objects.get(id=exit_id)
            exit_status.updatedby = request.user
            selected_exit_reason = request.POST.get('exit_type')
            exit_status.exit_type = ExitType.objects.get(id=selected_exit_reason)
            exit_status.employee = Employee.objects.get(id=employee)
            datereported_str = request.POST.get('date_reported')
            
       
            if datereported_str:
                datereported = parse_date(datereported_str)
            else:
                datereported = None
            exit_status.date_entered=datereported 

        except EmployeeExit.DoesNotExist:
            exit_status = EmployeeExit()
            exit_status.createdby = request.user
            selected_exit_reason = request.POST.get('exit_type')
            exit_status.exit_type = ExitType.objects.get(id=selected_exit_reason)
            exit_status.employee = Employee.objects.get(id=employee)
            datereported_str = request.POST.get('date_reported')
            
       
            if datereported_str:
                datereported = parse_date(datereported_str)
            else:
                datereported = None
        exit_status.date_entered=datereported
           
        
        exit_status.save()

        messages.success(request,
                         f'Details successfully updated.')
        # return redirect('employee_detail', employee_id=employee.id)
        return redirect('employee_detail', employee_id=employee)
    

def log_maternal_mortality(request):
    if request.method == 'POST':
        # Get dhis2ID from POST data
        mortality_id = request.POST.get('mortality_id')
        if mortality_id is None or mortality_id == '':
            mortality_id = 0
        else:
            mortality_id = int(mortality_id)

        county_id = request.POST.get('county_id')
        # print(county_id)
        mortality_type = request.POST.get('mortality_type')
        # employee = get_object_or_404(Employee, id=employee)

        # Try to get the existing action item, or create a new one if not found
        try:
            mortality_instance = MortalityLog.objects.get(id=mortality_id)
            mortality_instance.updatedby = request.user
            county = request.POST.get('county_id')
            mortality_instance.county=County.objects.get(id=county)
            mortality_instance.mortality_type=MortalityType.objects.get(id=mortality_type)
            # mortality_instance.date_reported = request.POST.get('date_reported')
            mortality_instance.mortality_count = request.POST.get('mortality_count')
            
            datereported_str = request.POST.get('date_reported')
            
       
            if datereported_str:
                datereported = parse_date(datereported_str)
            else:
                datereported = None
            mortality_instance.date_reported=datereported 

        except MortalityLog.DoesNotExist:
            mortality_instance = MortalityLog()
            mortality_instance.createdby = request.user
            county = request.POST.get('county_id')
            mortality_instance.county=County.objects.get(id=county)
            mortality_instance.mortality_type=MortalityType.objects.get(id=mortality_type)
            # mortality_instance.date_reported = request.POST.get('date_reported')
            mortality_instance.mortality_count = request.POST.get('mortality_count')
            
            datereported_str = request.POST.get('date_reported')
            
       
            if datereported_str:
                datereported = parse_date(datereported_str)
            else:
                datereported = None
        mortality_instance.date_reported=datereported 
           
        
        mortality_instance.save()

        messages.success(request,
                         f'Details successfully updated.')
       
        return redirect('mortality_detail')  

def log_neonatal_mortality(request):
    if request.method == 'POST':
        # Get dhis2ID from POST data
        mortality_id = request.POST.get('neonatal_mortality_id')
        if mortality_id is None or mortality_id == '':
            mortality_id = 0
        else:
            mortality_id = int(mortality_id)

        county_id = request.POST.get('neonatal_county_id')
        mortality_type = request.POST.get('neonatal_mortality_type')
        # employee = get_object_or_404(Employee, id=employee)

        # Try to get the existing action item, or create a new one if not found
        try:
            mortality_instance = MortalityLog.objects.get(id=mortality_id)
            mortality_instance.updatedby = request.user
            mortality_instance.county=County.objects.get(id=county_id)
            mortality_instance.mortality_type=MortalityType.objects.get(id=mortality_type)
            # mortality_instance.date_reported = request.POST.get('date_reported')
            mortality_instance.mortality_count = request.POST.get('neonatal_mortality_count')
            
            datereported_str = request.POST.get('neonatal_date_reported')
            
       
            if datereported_str:
                datereported = parse_date(datereported_str)
            else:
                datereported = None
            mortality_instance.date_reported=datereported 

        except MortalityLog.DoesNotExist:
            mortality_instance = MortalityLog()
            mortality_instance.createdby = request.user
            mortality_instance.county=County.objects.get(id=county_id)
            mortality_instance.mortality_type=MortalityType.objects.get(id=mortality_type)
            # mortality_instance.date_reported = request.POST.get('date_reported')
            mortality_instance.mortality_count = request.POST.get('neonatal_mortality_count')
            
            datereported_str = request.POST.get('neonatal_date_reported')
            
       
            if datereported_str:
                datereported = parse_date(datereported_str)
            else:
                datereported = None
        mortality_instance.date_reported=datereported 
           
        
        mortality_instance.save()

        messages.success(request,
                         f'Details successfully updated.')
       
        return redirect('mortality_detail')        

def get_subcounties_in_county(request):
    county = request.GET.get('county', '')
    
    if county:
        # Fetch mentors with the selected first name
        subcounties = SubCounty.objects.filter(county=county).values(
            'id', 'subCounty','county'
        ).distinct()
        
        # Prepare data with full name and ID
        subcounty_data = [
            {
                'id': subcounty['id'],
                'full_name': f"{subcounty['county']} {subcounty['subCounty'].capitalize()}"
            }
            for subcounty in subcounties
        ]
    else:
        subcounty_data = []

    return JsonResponse(subcounty_data, safe=False)

def get_facilities_in_subcounty(request):
    subcounty = request.GET.get('subcounty', '')
    
    if subcounty:
        # Fetch mentors with the selected first name
        facility_list = Healthfacility.objects.filter(subcounty=subcounty).values(
            'id', 'name'
        ).distinct()
        
        # Prepare data with full name and ID
        facility_data = [
            {
                'id': facility['id'],
                'full_name': f"{facility['name']}"
            }
            for facility in facility_list
        ]
    else:
        facility_data = []

    return JsonResponse(facility_data, safe=False)

@transaction.atomic
@login_required
def create_employee_record(request):
    if request.method == 'POST':
            # Retrieve individual field values
            employment_no = request.POST.get('employee_no')
            nursing_reg_no = request.POST.get('nursing_no')
            firstname = request.POST.get('firstname')
            middle_name = request.POST.get('middlename')
            lastname = request.POST.get('lastname')
            birthdate_str = request.POST.get('dob')
            if birthdate_str:
                birthdate = datetime.strptime(birthdate_str, '%Y-%m-%d').date()
            else:
                birthdate = None
            dob = birthdate 

            hiredate_str = request.POST.get('date_hired')
            if hiredate_str:
                hiredate = datetime.strptime(hiredate_str, '%Y-%m-%d').date()
            else:
                hiredate = None
            hire_date = hiredate  

            gender = request.POST.get('gender')
            email = request.POST.get('email')
            phone = request.POST.get('phone')
            current_subcounty = request.POST.get('subcounty_full_name')
            subcounty = SubCounty.objects.get(id=current_subcounty)
            sub_county=subcounty
            createdby=request.user

            selected_qualification = request.POST.get('qualification')
            qualification = QualificationType.objects.get(id=selected_qualification)
            current_date = datetime.now().date()

            selected_engagement = request.POST.get('engagement_type')
            engagement = EmploymentType.objects.get(id=selected_engagement)
            
            employee = Employee.objects.create(employment_no=employment_no, firstname=firstname,middle_name=middle_name,lastname=lastname,
                                                 dob=dob, hire_date=hire_date,gender=gender,email=email, \
                                                 phone=phone, \
                                                 sub_county=sub_county,createdby=createdby, updatedby=createdby, nursing_reg_no=nursing_reg_no
                                                 )
            
            EmployeeQualification.objects.create(
            employee=employee,
            qualification=qualification,
            #date_obtained=date_obtained
            date_entered=current_date,
            createdby=createdby, updatedby=createdby)

            
            StaffEmploymentTypeRelation.objects.create(
            employee=employee,
            employment_type=engagement,
            createdby=createdby, updatedby=createdby
           )

        
            messages.success(request, 'Staff with the number ' + str(employment_no) + ' created successfully.')
            return redirect('dp_employee_list')
            

@login_required    
def update_employee_record(request, id):
    if request.method == 'POST':
        this_employee= get_object_or_404(Employee, id=id)
        this_employee.employment_no = request.POST.get('edit_employee_no')
        this_employee.firstname = request.POST.get('edit_firstname')
        this_employee.middle_name = request.POST.get('edit_middlename')
        this_employee.lastname = request.POST.get('edit_lastname')
        birthdate_str = request.POST.get('edit_dob')
        if birthdate_str:
                birthdate = datetime.strptime(birthdate_str, '%Y-%m-%d').date()
        else:
                birthdate = None
        this_employee.dob = birthdate 

        hiredate_str = request.POST.get('edit_date_hired')
        if hiredate_str:
                hiredate = datetime.strptime(hiredate_str, '%Y-%m-%d').date()
        else:
                hiredate = None
        this_employee.hire_date = hiredate  

        this_employee.gender = request.POST.get('edit_gender')
        this_employee.email = request.POST.get('edit_email')
        this_employee.phone = request.POST.get('edit_phone')
        current_subcounty = request.POST.get('edit_subcounty_full_name')
        subcounty = SubCounty.objects.get(id=current_subcounty)
        this_employee.sub_county=subcounty
        this_employee.updatedby = request.user
        this_employee.save()

        messages.success(request, 'Records of staff number : ' + str(this_employee.employment_no) + ' updated successfully.')
        return redirect('dp_employee_list') 

@login_required
def delete_employee_record(request):
    record_id = request.POST.get('id')
    record = get_object_or_404(Employee, id=record_id)
    record.delete()
    #return redirect('your_success_url')
    messages.success(request, 'record with the ID ' + str(record_id) + ' deleted successfully.')
    return redirect('dp_employee_list')


def employee_data(request):
    data = list(Employee.objects.all().values('employment_no', 'hire_date'))
    return JsonResponse(data, safe=False)

def chart(request):
    return render(request, 'chart.html')

def get_employee_qualification_data():
    with connection.cursor() as cursor:
        # Execute the custom SQL query
        cursor.execute('''
            SELECT qt.description as qualification, count(qualification_id) as staff_count 
FROM employee_qualification eq join qualification_types qt on qt.id=eq.qualification_id
group by qt.description;
        ''')
        # Fetch all results
        rows = cursor.fetchall()

    # Convert query results to a list of dictionaries
    results = [
        {
            'qualification': row[0],
            'staff_count': row[1],
            
        }
        for row in rows
    ]

    return results

def employee_qualification_json(request):
    data = get_employee_qualification_data()
    return JsonResponse(data, safe=False)


def get_employee_engagementtype_data():
    with connection.cursor() as cursor:
        # Execute the custom SQL query
        cursor.execute('''
            SELECT description as engagementtype,count(employee_id) as staff_count
FROM staff_employmenttype_relation etr join employment_types et on et.id=etr.employment_type_id
group by description;
        ''')
        # Fetch all results
        rows = cursor.fetchall()

    # Convert query results to a list of dictionaries
    results = [
        {
            'engagementtype': row[0],
            'staff_count': row[1],
            
        }
        for row in rows
    ]

    return results

def employee_engagement_json(request):
    data = get_employee_engagementtype_data()
    return JsonResponse(data, safe=False)

def employee_age_json(request):
    data = get_employee_age_data()
    return JsonResponse(data, safe=False)

def employee_hiretrends_json(request):
    data = get_employee_hiretrends_data()
    return JsonResponse(data, safe=False)

# def qualificationchart(request):
#     return render(request, 'hrisdashboard2.html')

def qualificationchart(request):
    return render(request, 'dashboard.html')


def staff_dashboard(request):
    staff_summary=NurseMidStaffEnrollmentSummary.objects.all().values('id','employment_no','date_to_license_expiry','gender','qualification','hire_date','age').annotate(staff_count=Count('id'))
    active_staff=staff_summary.filter(is_active=1).count()
    license_summary=staff_summary.filter(date_to_license_expiry__gt=1, is_active=1)
    licenses_pending_renewal = staff_summary.filter(is_active=1).count()-license_summary.count()
    males=staff_summary.filter(gender="M", is_active=1)
    females=staff_summary.filter(gender="F", is_active=1)

    exits=staff_summary.filter(is_active=0)

    staff_summary2 = NurseMidStaffEnrollmentSummary.objects.values('qualification')\
    .annotate(staff_count=Count('id'))

    hire_year_summary = NurseMidStaffEnrollmentSummary.objects.annotate(
        hire_year=TruncYear('hire_date')  # Truncate the hire_date to the year
    ).values('hire_year').annotate(staff_count=Count('id'))

    hire_years = [item['hire_year'].year for item in hire_year_summary]
    hireyears_staff_counts = [item['staff_count'] for item in hire_year_summary]

    qualifications = [item['qualification'] for item in staff_summary2]
    staff_counts = [item['staff_count'] for item in staff_summary2]

    #attrition_logs=EmployeeExit.objects.all().values('id','exit_type','date_entered','exit_type__description')

    attrition_logs = (EmployeeExit.objects
                      .annotate(year=ExtractYear('date_entered'))  # Extract year from date_entered
                      .values('year', 'exit_type__description')  # Group by year and exit type description
                      .annotate(exit_count=Count('id'))  # Count the exits per exit type
                      .order_by('year', '-exit_count'))  # Order by year and count (descending)

    # Prepare the data for Chart.js
    exit_years = []  # Changed variable name to exit_years
    yearly_exit_counts = []  # Changed variable name to yearly_exit_counts
    leading_exit_types = []  # Kept the variable name for leading_exit_types

    # Track the leading exit type per year
    current_year = None
    current_year_exit_types = {}

    for log in attrition_logs:
        year = log['year']
        description = log['exit_type__description']
        count = log['exit_count']

        if year != current_year:
            if current_year is not None:
                # When switching to a new year, store the most frequent exit type
                leading_exit_types.append(current_year_exit_types.get('description', 'N/A'))
                yearly_exit_counts.append(current_year_exit_types.get('count', 0))
            exit_years.append(year)
            current_year_exit_types = {
                'description': description,
                'count': count
            }
            current_year = year
        else:
            # Compare and store the exit type with the most occurrences for this year
            if count > current_year_exit_types['count']:
                current_year_exit_types = {
                    'description': description,
                    'count': count
                }

    # Append the final year's data
    if current_year is not None:
        leading_exit_types.append(current_year_exit_types.get('description', 'N/A'))
        yearly_exit_counts.append(current_year_exit_types.get('count', 0))


    age_groups = {
        "8-25": 0,"26-35": 0,"36-45": 0, "46-55": 0, "56-65": 0, "66-70": 0, "70+": 0, "Others": 0,
    }

    staff_age = NurseMidStaffEnrollmentSummary.objects.all().values('id', 'age')

    # Count the number of IDs in each age range
    for staff_member in staff_age:
        age = staff_member['age']
        
        if age is not None:
            if 8 <= age <= 25:
                age_groups["8-25"] += 1
            elif 26 <= age <= 35:
                age_groups["26-35"] += 1
            elif 36 <= age <= 45:
                age_groups["36-45"] += 1
            elif 46 <= age <= 55:
                age_groups["46-55"] += 1
            elif 56 <= age <= 65:
                age_groups["56-65"] += 1
            elif 66 <= age <= 70:
                age_groups["66-70"] += 1
            elif age > 70:
                age_groups["70+"] += 1
        else:
            # For entries without an age (possibly invalid or missing)
            age_groups["Others"] += 1

    # Prepare data for Chart.js
    age_labels = list(age_groups.keys())  # Age group labels
    age_data = list(age_groups.values()) 

    if staff_summary.count() > 0:
        active_license_percentage = round((license_summary.count() / active_staff) * 100, 1)
        active_license_percentage = f"{active_license_percentage}%"  # Append '%' symbol

        males_percentage = round((males.count() / staff_summary.count()) * 100, 1)
        males_percentage = f"{males_percentage}%"

        females_percentage = round((females.count() / staff_summary.count()) * 100, 1)
        females_percentage = f"{females_percentage}%"

        exits_percentage = round((exits.count() / staff_summary.count()) * 100, 1)
        exits_percentage = f"{exits_percentage}%"

        pending_renewal_percentage = round((licenses_pending_renewal / active_staff) * 100, 1)
        pending_renewal_percentage = f"{pending_renewal_percentage}%"
    else:
        active_license_percentage = "0.0%"
        males_percentage = "0.0%"
        females_percentage = "0.0%"
        pending_renewal_percentage = "0.0%"
    
    context={
     'summary_list':staff_summary,   
     'active_staff':active_staff,   
     'staff_count':staff_summary.count,
     'active_licenses':license_summary.count,
     'active_license_percentage':active_license_percentage,
     'males':males.count,
     'males_percent':males_percentage,
     'females':females.count,
     'females_percent':females_percentage,
     'exits':exits.count,
     'exits_percent':exits_percentage,
     'qualifications': qualifications,
     'staff_counts': staff_counts,
     'hire_years': hire_years,
     'hireyears_staff_counts': hireyears_staff_counts,
     'age_labels': age_labels,
     'age_data': age_data,
     'exit_years': exit_years,
     'yearly_exit_counts': yearly_exit_counts,
     'leading_exit_types': leading_exit_types,
     'licenses_pending_renewal': licenses_pending_renewal,
     'pending_renewal_percentage': pending_renewal_percentage,
     
    }
    return render(request, 'dashboard_staff.html', context)


