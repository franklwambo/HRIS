import requests

def send_message(receiver, message_context):
    # Define your API credentials
    username = 'franklwambo'
    api_key = 'XlAcaJSETi1GJPX78cjHmylwtNV68KH9H7v0oKC5xfviiMYs53'
    sender_id = 'SMARTLINK'
    
    # Create the message payload
    post_data = {
        'username': username,
        'api_key': api_key,
        'sender': sender_id,
        'to': receiver,
        'message': message_context,
        'msgtype': 5,  # Message type
        'dlr': 0,      # Delivery report (0 = no report)
    }
    
    url = "https://sms.movesms.co.ke/api/compose?"
    
    try:
        # Send the POST request
        response = requests.post(url, data=post_data, verify=False)  # verify=False to bypass SSL verification
        
        # Print the response (for debugging)
        print(response.text)
        
        # Check for HTTP request errors
        response.raise_for_status()  # Raises HTTPError for bad responses
        
    except requests.exceptions.RequestException as e:
        # Handle any request-related errors (e.g., connection issues)
        print(f"An error occurred: {e}")
        

# Example usage
receiver = "+254729564904"  # Replace with the actual receiver's phone number
message = "I am testing this alert for the nursing counsil system"  # The message to send

send_message(receiver, message)
