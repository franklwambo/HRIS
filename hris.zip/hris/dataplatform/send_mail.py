import smtplib
from email.mime.text import MIMEText
from email.mime.multipart import MIMEMultipart
from email.utils import formataddr

# Email configuration
smtp_server = 'mail.franktech-solutions.co.ke'  # e.g., mail.yourdomain.com
smtp_port = 465  # For SSL
username = 'info@franktech-solutions.co.ke'
password = 'Maun2806;'
from_email = 'info@franktech-solutions.co.ke'
display_name = 'Nursing HRIS Admin'  # Your desired display name
to_email = 'fopiyo@jhpiego.org'
subject = 'MoH Nursing HRIS Monthly Alert'
body = 'This is a reminder to complete the maternal and neonatal mortality report.'

# Create the email
msg = MIMEMultipart()
msg['From'] = formataddr((display_name, from_email))
msg['To'] = to_email
msg['Subject'] = subject
msg.attach(MIMEText(body, 'plain'))

try:
    # Connect to the server
    with smtplib.SMTP_SSL(smtp_server, smtp_port) as server:
        server.login(username, password)
        server.sendmail(from_email, to_email, msg.as_string())
        print('Email sent successfully!')
except Exception as e:
    print(f'Failed to send email: {e}')
