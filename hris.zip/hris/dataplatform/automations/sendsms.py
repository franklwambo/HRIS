import requests

url = "https://sms.movesms.co.ke/api/compose?api_key=XlAcaJSETi1GJPX78cjHmylwtNV68KH9H7v0oKC5xfviiMYs53&sender=SMARTLINK&username=franklwambo&to=254729564904&message=testing this message&msgtype=5&dlr=0"

# username = 'franklwambo'
# api_key = 'XlAcaJSETi1GJPX78cjHmylwtNV68KH9H7v0oKC5xfviiMYs53'
# sender_id = 'SMARTLINK'
# username = 'franklwambo'
# destination  = '254729564904'
# message_details='I am testing this within python'

# url = f'https://sms.movesms.co.ke/api/compose?api_key={api_key}&sender={sender_id}&username={username}&to={destination}&message={message_details}&msgtype=5&dlr=0'

payload = {
'username' : 'franklwambo',
'api_key' :'XlAcaJSETi1GJPX78cjHmylwtNV68KH9H7v0oKC5xfviiMYs53',
'sender_id':'SMARTLINK',
'username' :'franklwambo',
'destination' : '254729564904',
'message_details': 'I am testing this within python',
'msgtype' : 5,
'dlr' : 0,
}
headers = {

    "Content-Type": "application/json",
    "Authorization": "Bearer XlAcaJSETi1GJPX78cjHmylwtNV68KH9H7v0oKC5xfviiMYs53"
}

response = requests.request("POST", url, headers=headers, data=payload)

print(response.text)