from django.db import connection
def get_employee_age_data():
    with connection.cursor() as cursor:
        # Execute the custom SQL query
        cursor.execute('''
            SELECT age_ranges.age_range,
    IFNULL(SUM(CASE WHEN age_ranges.gender = 'M' THEN age_ranges.count ELSE 0 END), 0) AS males,
    IFNULL(SUM(CASE WHEN age_ranges.gender = 'F' THEN age_ranges.count ELSE 0 END), 0) AS females
FROM ( SELECT CASE WHEN TIMESTAMPDIFF(YEAR, dob, CURDATE()) BETWEEN 18 AND 25 THEN '18-25'
            WHEN TIMESTAMPDIFF(YEAR, dob, CURDATE()) BETWEEN 26 AND 35 THEN '26-35'
            WHEN TIMESTAMPDIFF(YEAR, dob, CURDATE()) BETWEEN 36 AND 45 THEN '36-45'
            WHEN TIMESTAMPDIFF(YEAR, dob, CURDATE()) BETWEEN 46 AND 55 THEN '46-55'
            WHEN TIMESTAMPDIFF(YEAR, dob, CURDATE()) BETWEEN 56 AND 65 THEN '56-65'
            WHEN TIMESTAMPDIFF(YEAR, dob, CURDATE()) > 65 THEN '65+'
            ELSE 'Others' END AS age_range,
        gender, COUNT(*) AS count FROM employee GROUP BY age_range, gender ) AS age_ranges
GROUP BY age_ranges.age_range ORDER BY age_ranges.age_range;
        ''')
        # Fetch all results
        rows = cursor.fetchall()

    # Convert query results to a list of dictionaries
    results = [
        {
            'age_group': row[0],
            'males': row[1],
            'females': row[2],
            
        }
        for row in rows
    ]

    return results


def get_employee_hiretrends_data():
    with connection.cursor() as cursor:
        # Execute the custom SQL query
        cursor.execute('''
            SELECT year(e.hire_date) as year,count(e.id) as staff_count,
            SUM(CASE WHEN employment_type_id = 1 THEN 1 ELSE 0 END) AS 'Fulltime',
            SUM(CASE WHEN employment_type_id = 2 THEN 1 ELSE 0 END) AS 'shortterm',
            SUM(CASE WHEN employment_type_id = 3 THEN 1 ELSE 0 END) AS 'intern'
            FROM employee e join staff_employmenttype_relation ser on ser.employee_id=e.id
            group by year(hire_date)
            order by year(hire_date);
        ''')
        # Fetch all results
        rows = cursor.fetchall()

    # Convert query results to a list of dictionaries
    results = [
        {
            'year': row[0],
            'staff_count': row[1],
            
        }
        for row in rows
    ]

    return results