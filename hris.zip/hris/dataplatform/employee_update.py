import requests
import mysql.connector
import csv
import os

# Constants
KC_URL = "https://kc.kobotoolbox.org/api/v1/"  # Replace with your Kobo API URL
TOKEN = "59a59622c27a85f3b96e15d1787fbbe36bad69b7"  # Replace with your API token
# XFORM_ID = "aZFfTMcMZDYf6RUFiwBuxf"
XFORM_ID = "2294849"

# MySQL connection parameters
db_config = {
    'user': 'root',
    'password': 'Maun2806;',
    'host': 'localhost',
    'database': 'nursing_hris'
}

# SQL query
query = """
SELECT e.nursing_reg_no as nursing_reg_no, e.id as database_id, 
       concat_ws(' ', nursing_reg_no, firstname, middle_name, lastname) as employee_details,
       employment_no, dob, gender, email, phone,
       hire_date, sc.countyName as county, sub_county_id, 
       lower(sc.subCounty) as sub_county, facility_id, 
       hf.name as health_facility
FROM nursing_hris.employee e  
JOIN sub_county sc ON sc.id = e.sub_county_id
JOIN health_facilities hf ON hf.id = e.facility_id
WHERE e.is_active = 1;
"""

# Set up headers with the token for authentication
headers = {
    "Authorization": f"Bearer {TOKEN}",
    "Content-Type": "application/json"
}

# Step 1: Connect to the MySQL database and fetch data
try:
    connection = mysql.connector.connect(**db_config)
    cursor = connection.cursor()
    cursor.execute(query)
    
    # Fetch all results
    results = cursor.fetchall()

    # Create a temporary CSV file
    csv_file_path = 'employee_list.csv'
    with open(csv_file_path, mode='w', newline='') as csv_file:
        writer = csv.writer(csv_file)
        # Write header
        writer.writerow([i[0] for i in cursor.description])
        # Write data rows
        writer.writerows(results)

except mysql.connector.Error as err:
    print(f"Database error: {err}")
finally:
    if cursor:
        cursor.close()
    if connection:
        connection.close()

# Step 2: Verify XForm ID
response = requests.get(f"{KC_URL}/forms/{XFORM_ID}", headers=headers)
if response.status_code == 200:
    print(f"XForm ID {XFORM_ID} is valid.")
else:
    print(f"Invalid XForm ID: {response.status_code} - {response.text}")
    exit()  # Exit if the XForm ID is not valid

# Step 3: Read data from the CSV file and upload to Kobo API
with open(csv_file_path, 'rb') as new_file:
    upload_response = requests.post(
        f"{KC_URL}/metadata.json",
        headers=headers,
        files={"file": new_file},
        data={"xform": XFORM_ID, "data_value": os.path.basename(csv_file_path)}  # Using the file name as data_value
    )

    if upload_response.status_code == 201:  # 201 Created means successful upload
        print(f"Uploaded new file: {os.path.basename(csv_file_path)}")
    else:
        print(f"Failed to upload new file: {upload_response.status_code} - {upload_response.text}")

# Clean up the temporary CSV file
os.remove(csv_file_path)