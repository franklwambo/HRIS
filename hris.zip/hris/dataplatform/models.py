from django.db import models
from django.contrib.auth.models import User
from datetime import date

class County(models.Model):
    id = models.AutoField(primary_key=True)
    countyName = models.CharField(max_length=30)

    def __str__(self):
        return self.countyName

    class Meta:
        db_table = 'county'

class UserCountyRelation(models.Model):
    id = models.AutoField(primary_key=True)
    hris_user = models.ForeignKey(User, on_delete=models.CASCADE,related_name='hris_user')
    county = models.ForeignKey(County, on_delete=models.CASCADE,related_name='assigned_county')
    is_active = models.BooleanField(default=True, null=True, blank=True)
    has_global_access = models.BooleanField(default=False, null=True, blank=True)
    phone_contact=models.CharField(max_length=15,default="254729564904")
    created_by = models.ForeignKey(User, on_delete = models.CASCADE, related_name='geographyrelation_created')
    updated_by = models.ForeignKey(User, on_delete = models.SET_NULL, null=True, blank=True, related_name='geographyrelation_updated')
    datecreated = models.DateTimeField(auto_now_add = True)
    dateUpdated = models.DateTimeField(auto_now=True)

    def __str__(self):
        return f'{self.hris_user.username} - {self.county} - - {self.phone_contact} - {self.datecreated}'  
    
    class Meta:
        db_table = 'user_county_relation'

class PermissionLevel(models.Model):
    # Define your permission levels
    READ_ONLY = 'read_only'
    READ_WRITE_DELETE = 'read_write_delete'
    READ_WRITE = 'read_write'
    PERMISSION_CHOICES = [
        (READ_ONLY, 'Read Only'),
        (READ_WRITE_DELETE, 'Read, Write, Delete'),
        (READ_WRITE, 'Read, Write'),
    ]

    user = models.ForeignKey(User, on_delete=models.CASCADE)
    model_name = models.CharField(max_length=100, null=True, blank=True)
    permission_level = models.CharField(max_length=20, choices=PERMISSION_CHOICES)
    datecreated = models.DateTimeField(auto_now_add = True)
    dateUpdated = models.DateTimeField(auto_now=True)
    def __str__(self):
        return f'{self.user.username} - {self.model_name} - {self.permission_level}'  

    class Meta:
        db_table = 'user_permission_level'        

class SubCounty(models.Model):
    id = models.AutoField(primary_key=True)
    county = models.ForeignKey(County, on_delete=models.CASCADE, related_name='sub_counties')
    countyName = models.CharField(max_length=30, blank=True, null=True)
    subCounty = models.CharField(max_length=30, blank=True, null=True)

    def __str__(self):
        return self.subCounty

    class Meta:
        db_table = 'sub_county'    

class MortalityType(models.Model):
    id = models.AutoField(primary_key=True)
    description = models.CharField(max_length=75)
    is_active = models.BooleanField(default=True)

    def __str__(self):
        return self.description

    class Meta:
        db_table = 'mortality_types'


class MortalityLog(models.Model):
    id = models.AutoField(primary_key=True)
    county = models.ForeignKey('County', on_delete=models.CASCADE, related_name='mortality_logs')
    mortality_type = models.ForeignKey(MortalityType, on_delete=models.CASCADE, related_name='mortality_logs')
    date_reported = models.DateField()
    mortality_count = models.IntegerField(null=True, blank=True)
    # start_date = models.DateField(null=True, blank=True)
    # end_date = models.DateField(null=True, blank=True)
    mortality_count = models.IntegerField(null=True, blank=True)
    createdby = models.ForeignKey(User, on_delete=models.CASCADE, related_name='mortality_logs_created')
    updatedby = models.ForeignKey(User, on_delete=models.CASCADE, null=True, blank=True, related_name='mortality_logs_updated')
    datecreated = models.DateTimeField(auto_now_add=True)
    dateupdated = models.DateTimeField(auto_now=True)

    def __str__(self):
        return f"Mortality Log {self.id} - {self.date_reported}"

    class Meta:
        db_table = 'mortality_logs'


class Healthfacility(models.Model):
    id = models.AutoField(primary_key=True)
    name = models.CharField(max_length=200)
    subcounty = models.ForeignKey(SubCounty, on_delete=models.CASCADE)
    owner = models.CharField(max_length=150, null=True, blank=True)
    date_entered = models.DateField()
    createdby = models.ForeignKey(User, on_delete=models.CASCADE, related_name='facility_created')
    updatedby = models.ForeignKey(User, on_delete=models.CASCADE, null=True, blank=True, related_name='facility_updated')
    datecreated = models.DateTimeField(auto_now_add=True)
    dateupdated = models.DateTimeField(auto_now=True, null=True, blank=True,)
    is_active = models.BooleanField(default=True)

    def __str__(self):
        return f"Employee: {self.employee}, Exit Type: {self.exit_type}, Date Entered: {self.date_entered}"

    class Meta:
        db_table = 'health_facilities' 


class Employee(models.Model):
    id = models.AutoField(primary_key=True)
    employment_no = models.CharField(max_length=15, blank=True, null=True)
    nursing_reg_no = models.CharField(max_length=25, blank=True, null=True)
    firstname = models.CharField(max_length=50)
    middle_name = models.CharField(max_length=50, blank=True, null=True)
    lastname = models.CharField(max_length=50)
    dob = models.DateField(null=True, blank=True)
    gender = models.CharField(max_length=1, choices=[('M', 'Male'), ('F', 'Female'), ('T', 'Other')], blank=True, null=True)
    email = models.EmailField(max_length=55, blank=True, null=True)
    phone = models.CharField(max_length=15, blank=True, null=True)
    hire_date = models.DateField(null=True, blank=True)
    sub_county = models.ForeignKey(SubCounty, on_delete=models.SET_NULL, blank=True, null=True, related_name='employees')
    facility = models.ForeignKey(Healthfacility, on_delete=models.CASCADE, default=1, related_name='employee_facility')
    createdby = models.ForeignKey(User, on_delete=models.CASCADE, related_name='employee_created')
    updatedby = models.ForeignKey(User, on_delete=models.CASCADE, null=True, blank=True, related_name='employee_updated')
    datecreated = models.DateTimeField(auto_now_add=True)
    dateupdated = models.DateTimeField(auto_now=True)
    is_active = models.BooleanField(default=True)

    def __str__(self):
        return f"{self.firstname} {self.lastname}"

    class Meta:
        db_table = 'employee'

    @property
    def age(self):
        today = date.today()
        return today.year - self.dob.year - ((today.month, today.day) < (self.dob.month, self.dob.day)) 



class AuthorizationCountyRelation(models.Model):
    id = models.AutoField(primary_key=True)
    username = models.ForeignKey(User, on_delete=models.CASCADE, related_name='authorization_username_relations')
    county = models.ForeignKey(County, on_delete=models.CASCADE, related_name='authorization_county_relations')
    is_active = models.BooleanField(default=True)

    def __str__(self):
        return f"Username: {self.username.username}, County: {self.county.countyName}"

    class Meta:
        db_table = 'authorization_county_relation'
        
class EmploymentType(models.Model):
    id = models.AutoField(primary_key=True)
    description = models.CharField(max_length=100)

    def __str__(self):
        return self.description

    class Meta:
        db_table = 'employment_types'    


class StaffEmploymentTypeRelation(models.Model):
    id = models.AutoField(primary_key=True)
    employee = models.ForeignKey(Employee, on_delete=models.CASCADE)
    employment_type = models.ForeignKey(EmploymentType, on_delete=models.CASCADE)
    createdby = models.ForeignKey(User, on_delete=models.CASCADE, related_name='staff_employmenttype_relation_created')
    updatedby = models.ForeignKey(User, on_delete=models.CASCADE, null=True, blank=True, related_name='staff_employmenttype_relation_updated')
    datecreated = models.DateTimeField(auto_now_add=True)
    dateupdated = models.DateTimeField(auto_now=True)
    is_active = models.BooleanField(default=True)

    def __str__(self):
        return f"Employee: {self.employee}, Employment Type: {self.employment_type}"

    class Meta:
        db_table = 'staff_employmenttype_relation'  

class StaffLicenseLog(models.Model):
    id = models.AutoField(primary_key=True)
    employee = models.ForeignKey(Employee, on_delete=models.CASCADE)
    date_renewed = models.DateField()
    expiry_date = models.DateField()
    createdby = models.ForeignKey(User, on_delete=models.CASCADE, related_name='licenselog_created')
    updatedby = models.ForeignKey(User, on_delete=models.CASCADE, null=True, blank=True, related_name='licenselog_updated')
    datecreated = models.DateTimeField(auto_now_add=True)
    dateupdated = models.DateTimeField(auto_now=True)
    is_active = models.BooleanField(default=True)

    def __str__(self):
        return f"Employee: {self.employee}, License expires on: {self.expiry_date}"

    class Meta:
        db_table = 'staff_practicing_licenselog'           

class QualificationType(models.Model):
    id = models.AutoField(primary_key=True)
    description = models.CharField(max_length=100)
    qualification_scale = models.IntegerField(blank=True,null=True)

    def __str__(self):
        return self.description

    class Meta:
        db_table = 'qualification_types'


class EmployeeQualification(models.Model):
    id = models.AutoField(primary_key=True)
    employee = models.ForeignKey(Employee, on_delete=models.CASCADE)
    qualification = models.ForeignKey(QualificationType, on_delete=models.CASCADE)
    qualification_specialization = models.CharField(max_length=150,null=True, blank=True)
    year_obtained = models.IntegerField(null=True, blank=True)
    date_entered = models.DateField(null=True, blank=True)
    createdby = models.ForeignKey(User, on_delete=models.CASCADE, related_name='employee_qualification_created')
    updatedby = models.ForeignKey(User, on_delete=models.CASCADE, null=True, blank=True, related_name='employee_qualification_updated')
    datecreated = models.DateTimeField(auto_now_add=True)
    dateupdated = models.DateTimeField(auto_now=True)
    is_active = models.BooleanField(default=True)

    def __str__(self):
        return f"Employee: {self.employee}, Qualification: {self.qualification}, Date Entered: {self.date_entered}"

    class Meta:
        db_table = 'employee_qualification'   


class ExitType(models.Model):
    id = models.AutoField(primary_key=True)
    description = models.CharField(max_length=75)
    is_active = models.BooleanField(default=True)

    def __str__(self):
        return self.description

    class Meta:
        db_table = 'exit_types'


class EmployeeExit(models.Model):
    id = models.AutoField(primary_key=True)
    employee = models.ForeignKey(Employee, on_delete=models.CASCADE)
    exit_type = models.ForeignKey(ExitType, on_delete=models.CASCADE)
    date_entered = models.DateField()
    createdby = models.ForeignKey(User, on_delete=models.CASCADE, related_name='employee_exit_created')
    updatedby = models.ForeignKey(User, on_delete=models.CASCADE, null=True, blank=True, related_name='employee_exit_updated')
    datecreated = models.DateTimeField(auto_now_add=True)
    dateupdated = models.DateTimeField(auto_now=True)
    is_active = models.BooleanField(default=True)

    def __str__(self):
        return f"Employee: {self.employee}, Exit Type: {self.exit_type}, Date Entered: {self.date_entered}"

    class Meta:
        db_table = 'employee_exit' 

        


class FacilityDepartment(models.Model):
    id = models.AutoField(primary_key=True)
    description = models.CharField(max_length=150)
    verbose_name = models.CharField(max_length=100, null=True, blank=True)

    def __str__(self):
        return self.description

    class Meta:
        db_table = 'facility_departments' 


class StaffDepartmentRelation(models.Model):
    id = models.AutoField(primary_key=True)
    employee = models.ForeignKey(Employee, on_delete=models.CASCADE)
    department = models.ForeignKey(FacilityDepartment, on_delete=models.CASCADE)
    department_other = models.CharField(max_length=25, blank=True, null=True)
    date_placed = models.DateField(null=True, blank=True)
    createdby = models.ForeignKey(User, on_delete=models.CASCADE, related_name='staff_department_relation_created')
    updatedby = models.ForeignKey(User, on_delete=models.CASCADE, null=True, blank=True, related_name='staff_department_relation_updated')
    datecreated = models.DateTimeField(auto_now_add=True)
    dateupdated = models.DateTimeField(auto_now=True)
    is_active = models.BooleanField(default=True)

    def __str__(self):
        return f"Employee: {self.employee.nursing_reg_no}, Employment Type: {self.department.description}"

    class Meta:
        db_table = 'staff_department_relation' 


class NurseMidStaffEnrollmentSummary(models.Model):
    id = models.IntegerField(primary_key=True)
    employment_no = models.CharField(max_length=100)
    nursing_reg_no = models.CharField(max_length=100)
    firstname = models.CharField(max_length=255)
    middle_name = models.CharField(max_length=255, null=True, blank=True)
    lastname = models.CharField(max_length=255)
    dob = models.DateField()
    age = models.IntegerField()
    gender = models.CharField(max_length=10)
    email = models.EmailField(null=True, blank=True)
    phone = models.CharField(max_length=15, null=True, blank=True)
    hire_date = models.DateField()
    datecreated = models.DateTimeField()
    dateupdated = models.DateTimeField()
    is_active = models.BooleanField()
    createdby_id = models.IntegerField()
    updatedby_id = models.IntegerField()
    sub_county = models.CharField(max_length=255)
    county = models.CharField(max_length=255)
    county_code = models.IntegerField()
    facilityname = models.CharField(max_length=255)
    facility_id = models.IntegerField()
    date_renewed = models.DateField(null=True, blank=True)
    expiry_date = models.DateField(null=True, blank=True)
    date_to_license_expiry = models.IntegerField()
    qualification = models.CharField(max_length=255)

    class Meta:
        managed = False  # Tells Django not to manage this model (view only)
        db_table = 'nursemid_staffenrollment_summary'  # Use the view name as the table name
        verbose_name = "Nurse/Mid Staff Enrollment Summary"
        verbose_name_plural = "Nurse/Mid Staff Enrollment Summaries"

    def __str__(self):
        return f"{self.firstname} {self.lastname} - {self.employment_no}"



