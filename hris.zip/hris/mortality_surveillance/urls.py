from django.urls import path
from django.contrib import admin
from . import views
from django.views.generic import TemplateView    

# urlpatterns = [

#     path('employees/', views.dp_employee_list, name='dp_employee_list'),
#     path('', views.dp_employee_list, name='dp_employee_list'),

# ]